# -*- coding: utf-8 -*-
####python 2.7#################################################################
#By Navarro Diaz, Gonzalo Pablo
#Write the calibration specifications
###############################################################################

###############################################################################
#---Functions list
###############################################################################


#---------------------------------------------------------------------------- 
def searchUref(UrefList,UrefNum):
    #open listUref file
    l=(UrefList.readlines())   
    Ulist=[]
    Ctlist=[]
    Cplist=[]
    omegalist=[]

    for i in range (len(l)):
        l[i] = l[i].rstrip('\n')               
        l[i]= l[i].split(' ')
        Ulist.append(float(l[i][0]))
        Ctlist.append(float(l[i][1]))
        Cplist.append(float(l[i][2]))
        if len(l[i])==4:
            omegalist.append(float(l[i][3]))

    Uref=False
    Ct=False
    Cp=False
    omega=False
    
    print(Ulist)
    
    #search in the list
    pos1=False
    diff=1000
    for i in range(len(Ulist)-1):
        if (UrefNum-Ulist[i])<diff and (UrefNum-Ulist[i]) >= 0:
            diff=UrefNum-Ulist[i]
            pos1=i
            print('pos1 '+str(pos1))
            print('Uref bottom ' +str(Ulist[pos1]))
            print('diff ' +str(diff))
    
    
    print('Ulist[pos1+1]' +str(Ulist[pos1+1]))
    print('Ulist[pos1+1]-Ulist[pos1]'+str(Ulist[pos1+1]-Ulist[pos1]))
    
    
    #interpolate
    Uref=UrefNum
    Ct= Ctlist[pos1] + (UrefNum-Ulist[pos1]) * (Ctlist[pos1+1]-Ctlist[pos1]) / (Ulist[pos1+1]-Ulist[pos1]) 
    Cp= Cplist[pos1] + (UrefNum-Ulist[pos1]) * (Cplist[pos1+1]-Cplist[pos1]) / (Ulist[pos1+1]-Ulist[pos1])
    if len(l[0])==4:
        omega= omegalist[pos1] + (UrefNum-Ulist[pos1]) * (omegalist[pos1+1]-omegalist[pos1]) / (Ulist[pos1+1]-Ulist[pos1])
    else:
        omega=0

    
    print('Uref : '+str(Uref))
    print('Ct : '+str(Ct))
    print('Cp : '+str(Cp))
    if len(l[0])==4:
        print('omega : '+str(omega))    

    data=[]
    data.append("Uref "+str(Uref)+";\n")
    data.append("Cp "+str(Cp)+";\n")
    data.append("Ct "+str(Ct)+";\n")
    if len(l[0])==4:
        data.append("omega "+str(omega)+";\n")
    return(data,Uref,omega)

#----------------------------------------------------------------------------   
def search(l,var):
    #search for var value in settings file (in C++ format)
    value=False
    for i in range(len(l)):
        if var+' ' in l[i]: #if its in the line
            if l[i].index(var+' ')== 0: #if its in the beginning of the line
                posi=0
                posf=0
                foundi=False
                foundf=False
                for j in range(len(l[i])):
                    if l[i][j] == ' ' and foundi==False:
                        posi=j
                        foundi=True
                    if l[i][j] == ';' and foundf==False:
                        posf=j
                        foundf=True
                value=l[i][posi:posf]
                print(var+' found in line: '+str(i+1)+', with value: '+value)
    return(value)

###############################################################################
#---beginnig of the script
###############################################################################   

import sys
#import math

#---open input files
UrefList=open(sys.argv[1],'r')
UrefNum=float(sys.argv[2])
UinfNum=float(sys.argv[4])

print('Uref: '+str(UrefNum))

#---call the functions
(data,Uref,omega)=searchUref(UrefList,UrefNum)

#---open output files
UrefFile=open(sys.argv[3],'w')

#---calculate the timestep for each model
D=126
R=D/2
minRes=D/32.0
deltaT_AL=round((minRes/(omega*R)),2)
deltaT_AD=round(0.5*(minRes/(UinfNum)),1)

#in case of very high velocities 
if deltaT_AL > deltaT_AD:
    deltaT_AL=deltaT_AD

#---write output files
for i in range(len(data)):
    UrefFile.write(data[i])
UrefFile.write("Uinf "+str(UinfNum)+";\n")
UrefFile.write("deltaT_AL "+str(deltaT_AL)+";\n")
UrefFile.write("deltaT_AD "+str(deltaT_AD)+";\n")
UrefFile.write("cellSize "+str(minRes)+";\n")
UrefFile.close()

